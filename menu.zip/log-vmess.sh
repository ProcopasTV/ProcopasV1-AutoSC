#!/bin/bash
echo -e "════════════════════════════════════════" | lolcat
echo -e "     ═══[$(cat /etc/xray/domain)]═══"
echo -e "════════════════════════════════════════" | lolcat
echo -e ""
echo -e " VMESS "
echo -e ""
echo -e "$(cat /etc/funny/log/vmess/vmess.log)"
echo -e ""
echo -e "════════════════════════════════════════" | lolcat
echo -e "Noted : Banned = akun mati 15 menit"
