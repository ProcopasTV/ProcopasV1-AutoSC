#!/bin/bash
run_banner() {
clear
echo -e "\e[33m ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m" | lolcat
echo -e "                 • FunnyVpn •                 "
echo -e "\e[33m ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m" | lolcat
echo -e ""
}

run_back() {
echo ""
read -p "Pres Enter kembali ke HOME : " jejeje        
menu-trojan.sh        
}

run_info() {
echo -e "Informasi menambah akun"
echo -e ""
echo -e "Format Limit IP login"
echo -e "0 untuk unlimited login"        
echo -e ""
echo -e "Format Limit Quota "
echo -e "0 untuk unlimited Quota"         
echo -e "\e[33m ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m" | lolcat
echo -e ""        
}

run_trojan() {
trojan=$(cat /root/.trojan)    
if [ $trojan = yes ]; then
add-trojan-gfw.sh
else
add-trojan.sh
fi    
}
    
run_template() {        
echo -e ""
echo -e "Just Info"
echo -e "Silahkan anda cari kata (run_output) "         
echo -e "Lalu tinggal anda edit dan tambah"
echo -e "Untuk keluar dari edtior pencet aja CTRL + X"        
read -p "Pres enter to Next : " kwow
nano /usr/bin/$(run_trojan)
}
    
gfw=$(ls -a /root | grep .trojan | wc -l)
if [[ $gfw -gt 0 ]]; then
echo > /dev/null
else
switch-trojan.sh
fi 
    
clear
echo -e "\e[32m════════════════════════════════════════" | lolcat
echo -e "             ═══[Trojan]═══"
echo -e "\e[32m════════════════════════════════════════" | lolcat
echo -e " 1)  Create Trojan Account"
echo -e " 2)  Trial Trojan Account"        
echo -e " 3)  Deleting Trojan Account"
echo -e " 4)  Renew Trojan Account"
echo -e " 5)  Check User Login Trojan"
echo -e " 6)  List Member Trojan"
echo -e " 7)  Log Banned user Multi Login"
echo -e " 8)  Switch ON/OFF Trojan GFW"
echo -e " 9)  Edit Template Akun Trojan"        
echo -e ""
echo -e "\e[1;32m══════════════════════════════════════════\e[m"
echo -e " x)   MENU UTAMA"
echo -e "\e[1;32m══════════════════════════════════════════\e[m"
echo -e ""
read -p "     Please Input Number  [1-4 or x] :  "  menu
echo -e ""
case $menu in
1)
run_banner
run_info
run_trojan
run_back
;;
2)
trial-trojan.sh
run_back
;;
3)
run_banner
del-trojan.sh
run_back
;;
4)
run_banner
renew-trojan-prem.sh
run_back
;;
5)
run_banner
cek-trojan.sh
run_back
;;
6)
list-trojan.sh
run_back
;;
7)
log-trojan.sh
run_back
;;
8)
switch-trojan.sh
;;
9)
run_banner
run_template
run_back
;;
x)
procopas
;;
*)
echo "Maaf Tuan salah tekan"
sleep 1
menu-trojan.sh
;;
esac


