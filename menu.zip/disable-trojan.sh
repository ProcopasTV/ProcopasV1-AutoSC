#!/bin/bash
user="$1"
login="$2"
max="$3"
total="$4"
run_var() {
lokasi=/etc/xray/trojan-ws.json
lama=$(cat $lokasi | grep $user | sed -n 2p)
baru=$(echo -e "#@#$lama")
}

run_mesin() {
sed -i "s/${lama}/${baru}/g" /etc/xray/trojan*
}

run_log() {
waktu=$(date)
echo -e "$waktu\nBanned User: $user Login: $login IP max: $max IP \n$total \n" >> /etc/funny/log/trojan/trojan.log
}

run_var
run_mesin
run_log
