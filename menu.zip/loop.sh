#!/bin/bash
for (( ; ; ))
do
quota
sleep 2
done
